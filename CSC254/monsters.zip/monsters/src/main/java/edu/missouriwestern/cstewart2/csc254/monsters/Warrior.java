package edu.missouriwestern.cstewart2.csc254.monsters;

public class Warrior extends Human {

    public Warrior() {
        super();
        symbol ="\uD83D\uDC82";
        strength = 1.4;
        aggressiveness = 1.0;
        setStamina(1.0 + Math.random());
        attackMessage = "Attacks skillfully with a sword";
    }
}
